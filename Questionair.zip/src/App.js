import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import "./App.css";
import Questions from "./View/Questions/Questions";

class App extends Component {
  constructor() {
    super();
    this.state = {};
  }

  render() {
    return (
      <div className="App">
        <Router>
          <Switch>
            <Route
              exact
              strict
              path="/"
              render={(props) => <Questions {...props} />}
            />
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
